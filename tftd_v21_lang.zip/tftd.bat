@echo off
attrib -r ufoexe\geoscape.exe > nul
attrib -r geodata\biglets.dat > nul
attrib -r geodata\smallset.dat > nul
attrib -r geodata\german.dat > nul
attrib -r geodata\german2.dat > nul
attrib -r geodata\french.dat > nul
attrib -r geodata\french2.dat > nul
attrib -r geodata\english.dat > nul
attrib -r geodata\english2.dat > nul
attrib -r geodata\spanish.dat > nul
attrib -r geodata\spanish2.dat > nul
attrib -r geodata\lang1.dat > nul
attrib -r geodata\lang2.dat > nul
attrib -r geodata\lang3.dat > nul
attrib -r flop_int\int07.lbm > nul
attrib -r flop_int\int15.lbm > nul
attrib -r flop_int\int20.lbm > nul
attrib -r geograph\geobord.scr > nul
cls
echo.
echo =============================================
echo == X-Com: Terror from the Deep             ==
echo == v2.1 + multilingual patch by sakaali    ==
echo =============================================
echo.
echo Choose your language:
echo  1. English / German / French / Spanish
echo  2. Polish (Polski)
echo  3. Czech (Cestina)
echo  4. Hungarian (Magyar)
echo  5. Italian (Italiano)
echo.
echo Make sure you pick the same language at the game's opening screen too.
echo.
choice /n /c:12345 [1-5]: 
if errorlevel ==5 goto ita
if errorlevel ==4 goto hun
if errorlevel ==3 goto cze
if errorlevel ==2 goto pol
if errorlevel ==1 goto eng
goto end

:eng
del geodata\biglets.dat > nul
del geodata\smallset.dat > nul
del geodata\english.dat > nul
del geodata\english2.dat > nul
del geodata\german.dat > nul
del geodata\german2.dat > nul
del geodata\french.dat > nul
del geodata\french2.dat > nul
del geodata\spanish.dat > nul
del geodata\spanish2.dat > nul
del geodata\lang1.dat > nul
del geodata\lang2.dat > nul
del geodata\lang3.dat > nul
del geograph\geobord.scr > nul
del flop_int\int07.lbm > nul
del flop_int\int15.lbm > nul
del flop_int\int20.lbm > nul
del ufoexe\geoscape.exe > nul
copy geodata\biglets.deu geodata\biglets.dat > nul
copy geodata\smallset.deu geodata\smallset.dat > nul
copy geodata\english.eng geodata\english.dat > nul
copy geodata\english2.eng geodata\english2.dat > nul
copy geodata\german.deu geodata\german.dat > nul
copy geodata\german2.deu geodata\german2.dat > nul
copy geodata\french.fra geodata\french.dat > nul
copy geodata\french2.fra geodata\french2.dat > nul
copy geodata\spanish.spa geodata\spanish.dat > nul
copy geodata\spanish2.spa geodata\spanish2.dat > nul
copy geodata\lang1.deu geodata\lang1.dat > nul
copy geodata\lang2.fra geodata\lang2.dat > nul
copy geodata\lang3.spa geodata\lang3.dat > nul
copy geograph\geobord.eng geograph\geobord.scr > nul
copy flop_int\int07.eng flop_int\int07.lbm > nul
copy flop_int\int15.eng flop_int\int15.lbm > nul
copy flop_int\int20.eng flop_int\int20.lbm > nul
copy ufoexe\geoscape.eng ufoexe\geoscape.exe > nul
terror.com
goto end

:pol
del geodata\biglets.dat > nul
del geodata\smallset.dat > nul
copy geodata\biglets.pol geodata\biglets.dat > nul
copy geodata\smallset.pol geodata\smallset.dat > nul
del flop_int\int07.lbm > nul
del flop_int\int15.lbm > nul
del flop_int\int20.lbm > nul
copy flop_int\int07.eng flop_int\int07.lbm > nul
copy flop_int\int15.eng flop_int\int15.lbm > nul
copy flop_int\int20.eng flop_int\int20.lbm > nul
goto pchi

:cze
del geodata\biglets.dat > nul
del geodata\smallset.dat > nul
copy geodata\biglets.cze geodata\biglets.dat > nul
copy geodata\smallset.cze geodata\smallset.dat > nul
del flop_int\int07.lbm > nul
del flop_int\int15.lbm > nul
del flop_int\int20.lbm > nul
copy flop_int\int07.eng flop_int\int07.lbm > nul
copy flop_int\int15.eng flop_int\int15.lbm > nul
copy flop_int\int20.cze flop_int\int20.lbm > nul
goto pchi

:hun
del geodata\biglets.dat > nul
del geodata\smallset.dat > nul
copy geodata\biglets.hun geodata\biglets.dat > nul
copy geodata\smallset.hun geodata\smallset.dat > nul
del flop_int\int07.lbm > nul
del flop_int\int15.lbm > nul
del flop_int\int20.lbm > nul
copy flop_int\int07.hun flop_int\int07.lbm > nul
copy flop_int\int15.hun flop_int\int15.lbm > nul
copy flop_int\int20.hun flop_int\int20.lbm > nul
goto pchi

:ita
del geodata\biglets.dat > nul
del geodata\smallset.dat > nul
copy geodata\biglets.deu geodata\biglets.dat > nul
copy geodata\smallset.deu geodata\smallset.dat > nul
del flop_int\int07.lbm > nul
del flop_int\int15.lbm > nul
del flop_int\int20.lbm > nul
copy flop_int\int07.eng flop_int\int07.lbm > nul
copy flop_int\int15.eng flop_int\int15.lbm > nul
copy flop_int\int20.ita flop_int\int20.lbm > nul
goto pchi

:pchi
del geodata\english.dat > nul
del geodata\english2.dat > nul
del geodata\german.dat > nul
del geodata\german2.dat > nul
del geodata\french.dat > nul
del geodata\french2.dat > nul
del geodata\spanish.dat > nul
del geodata\spanish2.dat > nul
del geodata\lang1.dat > nul
del geodata\lang2.dat > nul
del geodata\lang3.dat > nul
del geograph\geobord.scr > nul
del ufoexe\geoscape.exe > nul
copy geodata\english.pol geodata\english.dat > nul
copy geodata\english2.pol geodata\english2.dat > nul
copy geodata\german.cze geodata\german.dat > nul
copy geodata\german2.cze geodata\german2.dat > nul
copy geodata\french.hun geodata\french.dat > nul
copy geodata\french2.hun geodata\french2.dat > nul
copy geodata\spanish.ita geodata\spanish.dat > nul
copy geodata\spanish2.ita geodata\spanish2.dat > nul
copy geodata\lang1.cze geodata\lang1.dat > nul
copy geodata\lang2.hun geodata\lang2.dat > nul
copy geodata\lang3.ita geodata\lang3.dat > nul
copy geograph\geobord.pol geograph\geobord.scr > nul
copy ufoexe\geoscape.hun ufoexe\geoscape.exe > nul
terror.com
goto end

:end