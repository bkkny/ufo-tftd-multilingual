@echo off
attrib -r ufoexe\geoscape.exe > nul
attrib -r geodata\english.dat > nul
attrib -r geodata\english2.dat > nul
attrib -r geodata\french.dat > nul
attrib -r geodata\french2.dat > nul
attrib -r geodata\german.dat > nul
attrib -r geodata\german2.dat > nul
attrib -r geodata\biglets.dat > nul
attrib -r geodata\smallset.dat > nul
attrib -r geodata\lang1.dat > nul
attrib -r geodata\lang2.dat > nul
attrib -r geograph\geobord.scr > nul
cls
echo.
echo =============================================================================
echo == *** UFO: ENEMY UNKNOWN (a.k.a. X-COM UFO DEFENSE) ***                   ==
echo ==                                                                         ==
echo == Hungarian translation by Schulti  *  Polish translation by Artur Siupik ==
echo == Czech translation by Roman Janik                                        ==
echo == Finnish & Danish translation by X-Com community                         ==
echo == Spanish translation by Hector Gustavo Gimenez                           ==
echo ==                                                                         ==
echo == *** multilingual patch by sakaali ***                                   ==
echo =============================================================================
echo.
echo Choose your language:
echo  1. English / German / French
echo  2. Hungarian (Magyar)
echo  3. Polish (Polski)
echo  4. Czech (Cestina)
echo  5. Finnish (Suomi)
echo  6. Danish (Dansk)
echo  7. Spanish (Espanol)
echo.
echo Make sure you pick the same language at the game's opening screen too.
echo.
choice /n /c:1234567 [1-7]: 
if errorlevel ==7 goto esp
if errorlevel ==6 goto dnk
if errorlevel ==5 goto fin
if errorlevel ==4 goto hun
if errorlevel ==3 goto pol
if errorlevel ==2 goto hun
if errorlevel ==1 goto eng
goto end

:eng
del ufoexe\geoscape.exe > nul
del geodata\english.dat > nul
del geodata\english2.dat > nul
del geodata\french.dat > nul
del geodata\french2.dat > nul
del geodata\german.dat > nul
del geodata\german2.dat > nul
del geodata\biglets.dat > nul
del geodata\smallset.dat > nul
del geodata\lang1.dat > nul
del geodata\lang2.dat > nul
del geograph\geobord.scr > nul
copy geodata\english.eng geodata\english.dat > nul
copy geodata\english2.eng geodata\english2.dat > nul
copy geodata\french.fra geodata\french.dat > nul
copy geodata\french2.fra geodata\french2.dat > nul
copy geodata\german.deu geodata\german.dat > nul
copy geodata\german2.deu geodata\german2.dat > nul
copy geodata\lang1.deu geodata\lang1.dat > nul
copy geodata\lang2.fra geodata\lang2.dat > nul
copy geodata\biglets.eng geodata\biglets.dat > nul
copy geodata\smallset.eng geodata\smallset.dat > nul
copy geograph\geobord.eng geograph\geobord.scr > nul
copy ufoexe\geoscape.eng ufoexe\geoscape.exe > nul
go.com
goto end


:hun
del ufoexe\geoscape.exe > nul
del geodata\english.dat > nul
del geodata\english2.dat > nul
del geodata\french.dat > nul
del geodata\french2.dat > nul
del geodata\german.dat > nul
del geodata\german2.dat > nul
del geodata\biglets.dat > nul
del geodata\smallset.dat > nul
del geodata\lang1.dat > nul
del geodata\lang2.dat > nul
del geograph\geobord.scr > nul
copy geodata\english.hun geodata\english.dat > nul
copy geodata\english2.hun geodata\english2.dat > nul
copy geodata\french.cze geodata\french.dat > nul
copy geodata\french2.cze geodata\french2.dat > nul
copy geodata\german.pol geodata\german.dat > nul
copy geodata\german2.pol geodata\german2.dat > nul
copy geodata\lang1.pol geodata\lang1.dat > nul
copy geodata\lang2.cze geodata\lang2.dat > nul
copy geodata\biglets.eng geodata\biglets.dat > nul
copy geodata\smallset.eng geodata\smallset.dat > nul
copy geograph\geobord.hun geograph\geobord.scr > nul
copy ufoexe\geoscape.hun ufoexe\geoscape.exe > nul
go.com
goto end

:pol
del ufoexe\geoscape.exe > nul
del geodata\english.dat > nul
del geodata\english2.dat > nul
del geodata\french.dat > nul
del geodata\french2.dat > nul
del geodata\german.dat > nul
del geodata\german2.dat > nul
del geodata\biglets.dat > nul
del geodata\smallset.dat > nul
del geodata\lang1.dat > nul
del geodata\lang2.dat > nul
del geograph\geobord.scr > nul
copy geodata\english.hun geodata\english.dat > nul
copy geodata\english2.hun geodata\english2.dat > nul
copy geodata\french.cze geodata\french.dat > nul
copy geodata\french2.cze geodata\french2.dat > nul
copy geodata\german.pol geodata\german.dat > nul
copy geodata\german2.pol geodata\german2.dat > nul
copy geodata\lang1.pol geodata\lang1.dat > nul
copy geodata\lang2.cze geodata\lang2.dat > nul
copy geodata\biglets.pol geodata\biglets.dat > nul
copy geodata\smallset.pol geodata\smallset.dat > nul
copy geograph\geobord.hun geograph\geobord.scr > nul
copy ufoexe\geoscape.hun ufoexe\geoscape.exe > nul
go.com
goto end

:fin
del ufoexe\geoscape.exe > nul
del geodata\english.dat > nul
del geodata\english2.dat > nul
del geodata\french.dat > nul
del geodata\french2.dat > nul
del geodata\german.dat > nul
del geodata\german2.dat > nul
del geodata\biglets.dat > nul
del geodata\smallset.dat > nul
del geodata\lang1.dat > nul
del geodata\lang2.dat > nul
del geograph\geobord.scr > nul
copy geodata\english.fin geodata\english.dat > nul
copy geodata\english2.fin geodata\english2.dat > nul
copy geodata\french.esp geodata\french.dat > nul
copy geodata\french2.esp geodata\french2.dat > nul
copy geodata\german.dnk geodata\german.dat > nul
copy geodata\german2.dnk geodata\german2.dat > nul
copy geodata\lang1.dnk geodata\lang1.dat > nul
copy geodata\lang2.esp geodata\lang2.dat > nul
copy geodata\biglets.eng geodata\biglets.dat > nul
copy geodata\smallset.eng geodata\smallset.dat > nul
copy geograph\geobord.fin geograph\geobord.scr > nul
copy ufoexe\geoscape.fin ufoexe\geoscape.exe > nul
go.com
goto end

:dnk
del ufoexe\geoscape.exe > nul
del geodata\english.dat > nul
del geodata\english2.dat > nul
del geodata\french.dat > nul
del geodata\french2.dat > nul
del geodata\german.dat > nul
del geodata\german2.dat > nul
del geodata\biglets.dat > nul
del geodata\smallset.dat > nul
del geodata\lang1.dat > nul
del geodata\lang2.dat > nul
del geograph\geobord.scr > nul
copy geodata\english.fin geodata\english.dat > nul
copy geodata\english2.fin geodata\english2.dat > nul
copy geodata\french.esp geodata\french.dat > nul
copy geodata\french2.esp geodata\french2.dat > nul
copy geodata\german.dnk geodata\german.dat > nul
copy geodata\german2.dnk geodata\german2.dat > nul
copy geodata\lang1.dnk geodata\lang1.dat > nul
copy geodata\lang2.esp geodata\lang2.dat > nul
copy geodata\biglets.dnk geodata\biglets.dat > nul
copy geodata\smallset.dnk geodata\smallset.dat > nul
copy geograph\geobord.fin geograph\geobord.scr > nul
copy ufoexe\geoscape.fin ufoexe\geoscape.exe > nul
go.com
goto end

:esp
del ufoexe\geoscape.exe > nul
del geodata\english.dat > nul
del geodata\english2.dat > nul
del geodata\french.dat > nul
del geodata\french2.dat > nul
del geodata\german.dat > nul
del geodata\german2.dat > nul
del geodata\biglets.dat > nul
del geodata\smallset.dat > nul
del geodata\lang1.dat > nul
del geodata\lang2.dat > nul
del geograph\geobord.scr > nul
copy geodata\english.fin geodata\english.dat > nul
copy geodata\english2.fin geodata\english2.dat > nul
copy geodata\french.esp geodata\french.dat > nul
copy geodata\french2.esp geodata\french2.dat > nul
copy geodata\german.dnk geodata\german.dat > nul
copy geodata\german2.dnk geodata\german2.dat > nul
copy geodata\lang1.dnk geodata\lang1.dat > nul
copy geodata\lang2.esp geodata\lang2.dat > nul
copy geodata\biglets.esp geodata\biglets.dat > nul
copy geodata\smallset.esp geodata\smallset.dat > nul
copy geograph\geobord.fin geograph\geobord.scr > nul
copy ufoexe\geoscape.fin ufoexe\geoscape.exe > nul
go.com
goto end

:end